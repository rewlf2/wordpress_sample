<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Astrid
 */

?>
    </div>
    </div>
    <!-- #content -->
    <div class="footer-wrapper">
        <div id="footer" class="container">
            <div class="flex-container">
                <div id="footer1" class="flex-item flex-2 section"> <img class="favicon" src="/wp-content/themes/astrid-ruderfinn/bak/img/cropped-Ficon.png"> </div>
                <div id="footer2" class="flex-item flex-1 section">

                    <?php echo do_shortcode( '[do_widget id=nav_menu-5 class=footer-widget]' ); ?>
                </div>
                <div id="footer3" class="flex-item flex-1 section">

                    <?php echo do_shortcode( '[do_widget id=nav_menu-6]' ); ?>
                </div>
                <div id="footer4" class="flex-item flex-2">
                    <div class="footer4-sub flex-container">
                        <div id="footer5" class="flex-item section">
                            <?php echo do_shortcode( '[do_widget id=nav_menu-7]' ); ?><?php echo do_shortcode('[do_widget id=nav_menu-9]'); ?>
                        </div>
                        <div id="footer6" class="flex-item section">
                            <?php echo do_shortcode( '[do_widget id=nav_menu-8]' ); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div id="footer4">
                    <div class="pull-right hidden-sm hidden-xs" style="padding:20px"> <img src="">
                        <p>&copy;2016 Ruder Finn Asia. All rights reserved</p><br>
                    </div>
                  <div class="text-center hidden-lg hidden-md"> <img src="">
                    <p>&copy;2016 Ruder Finn Asia. All rights reserved</p><br>
                  </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- #page -->
    <?php wp_footer(); ?><?php hoverfeaturedimg(); ?>
        </body>

        </html>